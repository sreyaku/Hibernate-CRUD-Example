package net.hibernate.util;

import java.util.Properties;

import javax.imageio.spi.ServiceRegistry;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;


import net.hibernate.model.Student;


public class HibernateUtil {
	private static SessionFactory sessionfactory;
	public static SessionFactory getsessionfactory()
	{
		if(sessionfactory == null) {
			try {
				Configuration conf= new Configuration();
				Properties settings= new Properties();
				settings.put(Environment.DRIVER, "com.mysql.jdbc.Driver");
				settings.put(Environment.URL, "jdbc:mysql://localhost:3306/hibernate?useSSL");
				settings.put(Environment.USER, "root");
				settings.put(Environment.PASS, "root1234@");
				settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL8Dialect");
				settings.put(Environment.SHOW_SQL,"true");
				settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS,"thread");
				settings.put(Environment.HBM2DDL_AUTO,"create_drop");
				conf.setProperties(settings);
				conf.addAnnotatedClass(Student.class);
				ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(conf.getProperties()).build();
				sessionfactory=conf.buildSessionFactory(serviceRegistry);
			}
			catch(Exception e) {
				e.printStackTrace();
				
			}
				
				
			
		
	}
	return sessionfactory;

}
}
