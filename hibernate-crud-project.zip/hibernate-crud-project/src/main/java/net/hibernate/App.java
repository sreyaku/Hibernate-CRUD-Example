package net.hibernate;

import java.util.List;

import net.hibernate.dao.StudentDao;
import net.hibernate.model.Student;

public class App {
	public static void main(String[] args) {
		StudentDao studentDao =new StudentDao();
		
		//testing saveStudent
		Student student= new Student("Student1","Student","stud1@gmail.com");
		studentDao.saveStudent(student);
		
		//testing updateStudent
		student.setFirstName("stud1");
		studentDao.updateStudent(student);
		
		//testing getStudentById
		Student student1 = studentDao.getStudentById(student.getId());
		
		//testing getAllStudents
		List<Student> students=studentDao.getAllStudents(student.getId());
		students.forEach(student2 ->System.out.println(student.getId()));
		
		//testing deleteStudent
		studentDao.deleteStudent(student.getId());
		
	}

}
