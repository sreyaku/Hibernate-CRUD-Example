package net.hibernate.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import net.hibernate.model.Student;
import net.hibernate.util.HibernateUtil;

public class StudentDao {
	public Student saveStudent(Student student) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getsessionfactory().openSession()) {
			
			// start transaction
			transaction = session.beginTransaction();
			
			// save student
			session.save(student);
			
			// commit the transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}
		return student;
	}

	public Student updateStudent(Student student) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getsessionfactory().openSession()) {
			
			// start transaction
			transaction = session.beginTransaction();
			
			// save or update student
			session.saveOrUpdate(student);
			
			// commit the transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}
		return student;
	}

	public Student getStudentById(long id) {
		Transaction transaction = null;
		Student student = null;
		try (Session session = HibernateUtil.getsessionfactory().openSession()) {
			// start transaction
			transaction = session.beginTransaction();
			
			// fetching details
			student = session.get(Student.class, id);
			// student=session.load(Student.class,id);
			
			// commit the transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}
		return student;
	}

	public List<Student> getAllStudents(long id) {
		Transaction transaction = null;
		List<Student> students = null;
		try (Session session = HibernateUtil.getsessionfactory().openSession()) {
			// start transaction
			transaction = session.beginTransaction();
			// get Students
			students = session.createQuerry("from Student").list();
			// save or update student
			// session.load(Student.class, id);
			// commit the transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}
		return students;
	}

	public void deleteStudent(long id) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getsessionfactory().openSession()) {
			// start transaction
			transaction = session.beginTransaction();

			// save or update student
			session.delete(student);

			// commit the transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
		}
	}
}